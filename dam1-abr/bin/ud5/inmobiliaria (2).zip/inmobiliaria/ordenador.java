package ud5.inmobiliaria;

import org.jetbrains.annotations.NotNull;

public class ordenador implements Comparable{


    @Override
    public int compareTo(@NotNull Object o) {
        return 0;
    }
}
