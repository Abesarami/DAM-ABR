package ud5.mulleres;

public interface IActivistas {
    public String getCausaDefendida();


}
