package ud5.abrexamen;

public class Servicio {
    String nombre;
    int puerto;
    String protocolo;

    public Servicio(String nombre, int puerto, String protocolo) {
        this.nombre = nombre;
        this.puerto = puerto;
        this.protocolo = protocolo;
    }
}
