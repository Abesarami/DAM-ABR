package ud5.mulleres;

public interface IPionera {
    public String getDescubrimientoOuAporte();

}
